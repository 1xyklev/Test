import pygame
import random

pygame.init()

WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("문제 3")

clock = pygame.time.Clock()  # FPS 제어 준비

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("dukbird.png")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH // 2, HEIGHT // 2)
        self.speed = 3

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.rect.y += self.speed

        # 화면 경계 제한
        self.rect.clamp_ip(screen.get_rect())

        super().__init__()
        self.image = pygame.image.load("dukbird.png")
        self.rect = self.image.get_rect()
        self.rect.centerx = screen_width - 40
        self.rect.bottom = screen_height - 10
        self.speed_x = 0

    def update(self):
        self.rect.x += self.speed_x
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > screen_width:
            self.rect.right = screen_width
            
    def shoot(self):
        bullet = Bullet(self.rect.centerx, self.rect.top)
        all_sprites.add(bullet)
        bullets.add(bullet)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((5, 20))
        self.image.fill(white)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speed_y = -2

    def update(self):
        self.rect.y += self.speed_y
        if self.rect.bottom < 0:
            self.kill()

def reset_game():
    global score, lives, game_over, all_sprites, aliens, bullets, player

    score = 5               
    lives = 3     
    game_over = False          # 게임 오버 해제

    # 스프라이트 그룹 재생성
    all_sprites.empty()
    aliens.empty()
    bullets.empty()

    # 플레이어 다시 생성
    player = Player()
    all_sprites.add(player)

    for _ in range(10):
        alien = Bullet()
        all_sprites.add(alien)
        aliens.add(alien)

# ------------------- 점수 -------------------
score = 0
# ------------------- 메인 루프 -------------------
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 스프라이트 업데이트
    all_sprites.update()

    # ---- 충돌 체크 ----
    hits = pygame.sprite.spritecollide(player, enemies, False)
    if hits:
        hit_sound.play()
        score += 1
        print("충돌! 현재 점수:", score)

    screen.fill(black)

    all_sprites.draw(screen)

    # 추가: 점수 & 목숨 UI
    ui_text = font.render(f"Lives: {lives}   Score: {score}", True, white)
    screen.blit(ui_text, (10, 10))

    # 추가: 게임오버 메시지
    if game_over:
        over_text = font.render("GAME OVER(Press R to Restart)", True, red)
        x = (screen_width - over_text.get_width()) // 2
        y = (screen_height - over_text.get_height()) // 2
        screen.blit(over_text, (x, y))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()