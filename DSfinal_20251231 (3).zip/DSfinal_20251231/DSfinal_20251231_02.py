# 문제 2번

from tkinter import *

class Person:
    def __init__(self, name: str):  # :str은 타입 힌트
        self.name = name

class HobbyPerson(Person):
    def __init__(self, name: str):
        super().__init__(name)
        self.add_hobby = []

    def enrollHobby(self, hobby: str):
        if hobby not in self.add_hobby:
            self.add_hobby.append(hobby)

    def clear_hobbeis(self):
        self.add_hobby.clear()

root = Tk()
root.title("문제2")
root.geometry("380x260")

s =  HobbyPerson("홍길동")
lb1 = Label(root, text=f"이름: {s.name}").pack(pady=8)

frame = Frame(root)
frame.pack(pady=10, anchor="center")

var_g = IntVar(selected_hobby=0)
var_r = IntVar(selected_hobby=0)
var_e = IntVar(selected_hobby=0)

Radiobutton(frame, text="게임", variable=var_g, value=0).grid(row=0, column=0, padx=8, pady=4)
Radiobutton(frame, text="독서", variable=var_r, value=0).grid(row=0, column=1, padx=8, pady=4)
Radiobutton(frame, text="운동", variable=var_e, value=0).grid(row=0, column=2, padx=8, pady=4)

result = StringVar(value="취미를 선택하고 [등록하기]를 누르세요.")
lb2 = Label(root, textvariable=result, wraplength=340, justify="left").pack(pady=10)

def register_hobby():
    s.clear_hobbeis()
    if var_g.get(): s.enrollHobby("게임")
    if var_r.get(): s.enrollHobby("독서")
    if var_e.get(): s.enrollHobby("운동")

    if s.add_hobby:
        result.set(f"현재 선택된 취미: {', '.join(s.add_hobby)}")
    else:
        result.set("선택된 취미가 없습니다.")

def reset_all():
    var_g.set(0)
    var_r.set(0)
    var_e.set(0)
    s.add_hobby()
    result.set("모든 선택을 해제했습니다.")

btn_frame = Frame(root)
btn_frame.pack(pady=6)

Button(btn_frame, text="등록하기", command=register_hobby).pack(side="left", padx=8)
Button(btn_frame, text="초기화", command=reset_all).pack(side="left", padx=8)

root.mainloop()