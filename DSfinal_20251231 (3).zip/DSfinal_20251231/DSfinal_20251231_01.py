import tkinter as tk

# ---------- 모델 (상속/오버라이딩/다형성) ----------
class DrawableShape:
    def draw(self, canvas):
        raise NotImplementedError 
    
class Square(DrawableShape):
    def __init__(self, x, y, size):
        self.x = x
        self.y = y
        self.size = size

    def draw(self, canvas):


class Circle(DrawableShape):
    def __init__(self, x, y, size):
    
        self.x = x
        self.y = y
        self.size = size

    def draw(self, canvas):

root = tk.Tk()
root.title("문제 1")
canvas = tk.Canvas(root, width=300, height=220, bg="white")
canvas.pack(pady=6)

btn_frame = tk.Frame(bottom)
btn_frame.pack(side="right")
tk.Button(frm, text="사각형 추가", value="rect", variable=var).pack(side="left", padx=6)
tk.Button(frm, text="원 추가", value="rect", variable=var).pack(side="left", padx=6)
tk.Button(frm, text="모두 그리기", value="rect", variable=var).pack(side="left", padx=6)